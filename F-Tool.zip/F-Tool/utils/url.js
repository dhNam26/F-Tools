{
     "FDc0d3": "F-Tool",
     "Proxies": [
          {
               "type": 1,
               "url": "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all",
               "timeout": 5
          },
          {
               "type": 1,
               "url": "https://www.proxy-list.download/api/v1/get?type=http&anon=elite&country=US",
               "timeout": 5
          },
          {
               "type": 1,
               "url": "https://api.proxyscrape.com/?request=displayproxies&proxytype=http",
               "timeout": 5
          },
          {
               "type": 1,
               "url": "https://api.openproxylist.xyz/http.txt",
               "timeout": 5
          },
          {
               "type": 2,
               "url": "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=https&timeout=10000&country=all&ssl=all&anonymity=all",
               "timeout": 5
          },
          {
               "type": 2,
               "url": "https://www.proxy-list.download/api/v1/get?type=https&anon=elite&country=US",
               "timeout": 5
          },
          {
               "type": 2,
               "url": "https://api.proxyscrape.com/?request=displayproxies&proxytype=https",
               "timeout": 5
          },
          {
               "type": 2,
               "url": "https://api.openproxylist.xyz/https.txt",
               "timeout": 5
          },
          {
               "type": 3,
               "url": "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks4&timeout=10000&country=all&ssl=all&anonymity=all",
               "timeout": 5
          },
          {
               "type": 3,
               "url": "https://www.proxy-list.download/api/v1/get?type=socks4&anon=elite&country=US",
               "timeout": 5
          },
          {
               "type": 3,
               "url": "https://api.proxyscrape.com/?request=displayproxies&proxytype=socks4",
               "timeout": 5
          },
          {
               "type": 3,
               "url": "https://api.openproxylist.xyz/socks4.txt",
               "timeout": 5
          },
          {
               "type": 4,
               "url": "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=10000&country=all&ssl=all&anonymity=all",
               "timeout": 5
          },
          {
               "type": 4,
               "url": "https://www.proxy-list.download/api/v1/get?type=socks5&anon=elite&country=US",
               "timeout": 5
          },
          {
               "type": 4,
               "url": "https://api.proxyscrape.com/?request=displayproxies&proxytype=socks5",
               "timeout": 5
          },
          {
               "type": 4,
               "url": "https://api.openproxylist.xyz/socks5.txt",
               "timeout": 5
          }
     ]
}